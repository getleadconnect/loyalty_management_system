@include:Importing a file|basics
@include:Handling results|results
@include:Selecting sheets and columns|select
@include:Dates|dates
@include:Calculation|calculation
@include:Caching and cell caching|cache
@include:Batch import|batch
@include:Import by config|config
@include:Extra|extra