#Config

Laravel Excel includes several config settings for import-, export-, view- and CSV-specific settings.
Use the artisan publish command to publish the config file to your project.

    php artisan config:publish maatwebsite/excel

The config files can now be found at `app/config/packages/maatwebsite/excel`
