@include:Installation|installation
@include:Config|config
@include:Requirements|requirements
@include:Contributing|contributing
@include:License|license